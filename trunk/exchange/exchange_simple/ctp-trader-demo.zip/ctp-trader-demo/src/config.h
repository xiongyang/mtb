#ifndef MD_CONFIG_H_
#define MD_CONFIG_H_
#pragma once

//������
int requestId=0;

// ǰ�õ�ַ
char mdFront[]   ="tcp://asp-sim2-front1.financial-trading-platform.com:26213";
char tradeFront[]="tcp://asp-sim2-front1.financial-trading-platform.com:26205";
#endif