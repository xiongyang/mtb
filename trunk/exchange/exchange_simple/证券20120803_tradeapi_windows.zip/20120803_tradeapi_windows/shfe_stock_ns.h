#ifndef _SHFE_STOCK_NAMESPACE_H_
#define _SHFE_STOCK_NAMESPACE_H_
//////////////////////////////////////////////////////////////////////////
/*
#define _SHFE_STOCK_NS_	_shfe_stock_
#define _SHFE_NS_STOCK_BEGIN_ namespace _shfe_stock_{
#define _SHFE_NS_STOCK_END_	}
#define _USING_SHFE_STOCK_NS_	using namespace _shfe_stock_; */
//////////////////////////////////////////////////////////////////////////
#define _SHFE_NS_STOCK_BEGIN_ 
#define _SHFE_NS_STOCK_END_	

#endif
